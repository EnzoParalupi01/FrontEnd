console.log("Ambiente configurado com sucesso!");
