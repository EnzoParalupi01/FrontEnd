
let nome = "Enzo";           
let idade = 17;             
let altura = 1.75;           
let programador = true;      

console.log("Nome:", nome);
console.log("Idade:", idade);
console.log("Altura:", altura);
console.log("Programador:", programador);
