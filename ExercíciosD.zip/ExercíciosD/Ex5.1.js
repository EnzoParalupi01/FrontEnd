var prompt = require('prompt-sync')();

function boasVindas(nome) {
    return "Olá, " + nome + "! Seja bem-vindo(a)!";
}

console.log(boasVindas("Lucas"));
