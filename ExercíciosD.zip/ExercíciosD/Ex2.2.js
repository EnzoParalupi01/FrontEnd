
let anoNascimento = 1998;
anoNascimento = String(anoNascimento);

console.log("Tipo de dado de anoNascimento:", typeof anoNascimento);

let peso = "80.5";
peso = Number(peso);

console.log("Peso como número:", peso);
console.log("Tipo de dado de peso:", typeof peso);
