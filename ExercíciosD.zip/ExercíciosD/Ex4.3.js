var prompt = require('prompt-sync')();

let contador = 10;

while (contador >= 1) {
    console.log(contador);
    contador--; 
}

console.log("Feliz Ano Novo!");
